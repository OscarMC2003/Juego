package clases;

public class Pruebas {
	public static void main(String args[]) {
		PersonajePower Power = new PersonajePower(275, 45);
		Enemigo enemigo1 = new Enemigo();
		
		System.out.println("vida enemigo antes: "+ enemigo1.getVida());
		Power.Sangre(enemigo1);
		System.out.println("vida enemigo despues: "+ enemigo1.getVida());
		
		LeerFichero f1 = new LeerFichero();
		f1.LeerPersonajes();
		
	}
	
	
}
