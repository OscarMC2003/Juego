package clases;

public interface HabilidadesEspecificas {
	//metodos
	public abstract void HabilidadClase();
}
