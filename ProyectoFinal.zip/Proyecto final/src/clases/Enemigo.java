package clases;

public class Enemigo {
	//atributos
	private int vida;
	private int ataque;
	
	//constructor
	public Enemigo() {
		this.vida = 350;
		this.ataque = 40;
	}
	
	//getters y setters
	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public int getAtaque() {
		return ataque;
	}

	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}
}
