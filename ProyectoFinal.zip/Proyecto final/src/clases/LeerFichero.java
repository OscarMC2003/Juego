package clases;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class LeerFichero {
	
	public void LeerPersonajes() {
		File f = new File ("datosPersonaje.txt");
		Scanner s;
		
		try {
			s=new Scanner(f);
			while(s.hasNextLine()) {
				String linea = s.nextLine();
				Scanner sl = new Scanner (linea);
				sl.useDelimiter("\\s*,\\s*");
				System.out.println(sl.next());
				System.out.println(sl.next());
				System.out.println(sl.next());
				System.out.println(sl.next());
			}
			s.close();
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
