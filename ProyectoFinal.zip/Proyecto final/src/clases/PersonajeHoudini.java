package clases;

public class PersonajeHoudini extends Personaje{
	//contructor
	public PersonajeHoudini(int vida, int ataque) {
		super(vida, ataque);
		
	}
	
	//ataque normal
	public void ataqueN(Enemigo enemigo1) {
		int vidaE = enemigo1.getVida() -35;
		enemigo1.setVida(vidaE);
		
	}
	
	//habilidad
	/*public void Retardini(Enemigo enemigo1) {
		int vidaE = enemigo1.getVida() -15;
		enemigo1.setVida(vidaE);
	}*/
	
	//habilidad de Mago
	public void HabilidadClase() {
		//turno enemigo -1
	}	
	
}
