package clases;

public class PersonajeAñya extends Personaje {
	//atributo
	private int cooldownHabilidad=0;
	
	//contructor
	public PersonajeAñya(int vida, int ataque) {
		super(vida, ataque);
		
	}
	
	//ataque normal
	public void ataqueN(Enemigo enemigo1) {
		int vidaE = enemigo1.getVida() -15;
		enemigo1.setVida(vidaE);
		
	}
	
	//habilidad
	public void Peanuts(Enemigo enemigo1) {
		if(cooldownHabilidad!=0) {
			System.out.printf("Te quedan %d turnos hasta que puedas usar la habilidad\n", cooldownHabilidad);
		}else {
			int vidaE = enemigo1.getVida() -30;
			enemigo1.setVida(vidaE);
			cooldownHabilidad=3;
		}
		
	}
	
	//habilidad de Healer
	public void HabilidadClase() {
		int vidaP=this.getVida() +20;
		this.setVida(vidaP);
	}
	
}
