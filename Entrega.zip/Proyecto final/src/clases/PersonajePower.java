package clases;

public class PersonajePower extends Personaje{
	//contructor
	public PersonajePower(int vida, int ataque) {
		super(vida, ataque);
		
	}
	
	
	//ataque normal
	public void ataqueN(Enemigo enemigo1) {
		int vidaE = enemigo1.getVida() - this.getAtaque();
		enemigo1.setVida(vidaE);
		
	}
	
	//habilidad
	public void HabilidadPersonaje(Enemigo enemigo1) {
		int vidaE = enemigo1.getVida() -15;
		enemigo1.setVida(vidaE);
	}

	//habilidad de DPS
	public void HabilidadClase() {
		int vidaP=this.getVida() -80;
		this.setVida(vidaP);
		int ataqueP=this.getAtaque() +20;
		this.setAtaque(ataqueP);
		
	}

}
