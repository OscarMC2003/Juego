package clases;

public class Arma{
	private int ataqueArma=0;
	private int vidaArma=0;
	
	//constructor
	public Arma(int ataqueArma, int vidaArma) {
		this.ataqueArma = ataqueArma;
		this.vidaArma = vidaArma;
	}
	
	public int getVidaArma() {
		return vidaArma;
	}

	public void setVidaArma(int vidaArma) {
		this.vidaArma = vidaArma;
	}

	//getters y setters
	public int getAtaqueArma() {
		return ataqueArma;
	}
	public void setAtaqueArma(int ataqueArma) {
		this.ataqueArma = ataqueArma;
	}
	

	
}
