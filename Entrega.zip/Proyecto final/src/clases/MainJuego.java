package clases;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class MainJuego {
	
	public static int NumEnemig = 0;
	public static String personaje;
	public static String arma;
	public static int dificultad = 0;
	public static int cooldownHabilidad=0;
	public static int contArray= 0;
	
	public static void main(String args[]) {
		
		Scanner scaner = new Scanner(System.in);
		String seleccionFichero;
		
		GestionVentanas();	//muestra las ventanas para la elección de personajes, armas, etc
		
		Enemigo enemigos[] = new Enemigo[NumEnemig];	//crea enemigos en función de los enemigos introducidos en la ventana
		for(int i=0; i<NumEnemig; i++){
			enemigos[i] = new Enemigo();
		}
		
		//crear personajes y armas
		PersonajeBestoFriendo BestoFriendo = new PersonajeBestoFriendo(0, 0);
		PersonajeAñya Añya = new PersonajeAñya(0, 0);
		PersonajePower Power = new PersonajePower(0, 0);
		PersonajeHoudini Houdini = new PersonajeHoudini(0, 0);
		
		Lanza Lanza = new Lanza(0, 0);
		Martillo Martillo = new Martillo(0, 0);
		Hacha Hacha = new Hacha(0, 0);
		Espada Espada = new Espada (0, 0);
		
		Arma[] arrayArmas = {Lanza, Martillo, Espada, Hacha};
		String arrayResultados[] = new String[1000];
		
		//lee los ficheros para inicializar las estadísticas de los personajes y las armas
		LeerFicheroJugadores(Power, Añya, Houdini, BestoFriendo);
		LeerFicheroArmas(Lanza, Martillo, Hacha, Espada);
		
		//en fución de lo elegido pasa unos parámetros para empezar la partida
		if(personaje == "Power") {
			if(arma == "Lanza") {
				arrayResultados[contArray]="Elegiste Power + Lanza\n";
				contArray++;
				GestionTurnos(Lanza, Power, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Hacha") {
				arrayResultados[contArray]="Elegiste Power + Hacha\n";
				contArray++;
				GestionTurnos(Hacha, Power, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Martillo") {
				arrayResultados[contArray]="Elegiste Power + Martillo\n";
				contArray++;
				GestionTurnos(Martillo, Power, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Espada") {
				arrayResultados[contArray]="Elegiste Power + Espada\n";
				contArray++;
				GestionTurnos(Espada, Power, enemigos, arrayArmas, arrayResultados);
			}
		}else if(personaje == "Añya") {
			if(arma == "Lanza") {
				arrayResultados[contArray]="Elegiste Añya + Lanza\n";
				contArray++;
				GestionTurnos(Lanza, Añya, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Hacha") {
				arrayResultados[contArray]="Elegiste Añya + Hacha\n";
				contArray++;
				GestionTurnos(Hacha, Añya, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Martillo") {
				arrayResultados[contArray]="Elegiste Añya + Martillo\n";
				contArray++;
				GestionTurnos(Martillo, Añya, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Espada") {
				arrayResultados[contArray]="Elegiste Añya + Espada\n";
				contArray++;
				GestionTurnos(Espada, Añya, enemigos, arrayArmas, arrayResultados);
			}
		}else if(personaje == "Besto") {
			if(arma == "Lanza") {
				arrayResultados[contArray]="Elegiste BestoFriendo + Lanza\n";
				contArray++;
				GestionTurnos(Lanza, BestoFriendo, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Hacha") {
				arrayResultados[contArray]="Elegiste BestoFriendo + Hacha\n";
				contArray++;
				GestionTurnos(Hacha, BestoFriendo, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Martillo") {
				arrayResultados[contArray]="Elegiste BestoFriendo + Martillo\n";
				contArray++;
				GestionTurnos(Martillo, BestoFriendo, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Espada") {
				arrayResultados[contArray]="Elegiste BestoFriendo + Espada\n";
				contArray++;
				GestionTurnos(Espada, BestoFriendo, enemigos, arrayArmas, arrayResultados);
			}
		}else if(personaje == "Houdini") {
			if(arma == "Lanza") {
				arrayResultados[contArray]="Elegiste Houdini + Lanza\n";
				contArray++;
				GestionTurnos(Lanza, Houdini, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Hacha") {
				arrayResultados[contArray]="Elegiste Houdini + Hacha\n";
				contArray++;
				GestionTurnos(Hacha, Houdini, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Martillo") {
				arrayResultados[contArray]="Elegiste Houdini + Martillo\n";
				contArray++;
				GestionTurnos(Martillo, Houdini, enemigos, arrayArmas, arrayResultados);
			}else if(arma == "Espada") {
				arrayResultados[contArray]="Elegiste Houdini + Espada\n";
				contArray++;
				GestionTurnos(Espada, Houdini, enemigos, arrayArmas, arrayResultados);
			}
		}
		else{
			System.out.println("Personaje no reconocido");
		}
		
		System.out.println("¿¿Deseas guardar los resultados en un fichero?? Y/N");
		seleccionFichero=scaner.next();
		
		switch(seleccionFichero) {
			case "N":
			case "n":
				System.out.println("Fin del programa");
				break;
			case "Y":
			case "y":
				FileWriter fichero = null;
				PrintWriter pw = null;
				
				try {
					fichero = new FileWriter("resultado.txt");
					pw = new PrintWriter(fichero);
					
					for(int i =0; i<1000; i++)
					{
						if(arrayResultados[i] != null) {
							pw.print(arrayResultados[i]);
						}
					}
					System.out.println("//FIN DE LA PARTIDA//");
				}catch(Exception e){
					e.printStackTrace();	
				}finally{
					try {
						if(null != fichero) {
							fichero.close();
						}
					}catch(Exception e2){
						e2.printStackTrace();
					}
					
				}
				break;
			default:
				System.out.println("Selección erronea, no se creara el fichero");
		}
	}
	
	public static void LeerFicheroJugadores(PersonajePower Power, PersonajeAñya Añya, PersonajeHoudini Houdini, PersonajeBestoFriendo BestoFriendo)
	{
		File f = new File ("datosPersonaje.txt");
		Scanner s;
		
		try {
				s = new Scanner(f);
				while(s.hasNext()){
					String personaje = s.next();
					//System.out.printf("%s\n", personaje);
					int ataque = Integer.parseInt(s.next());
					//System.out.printf("%d\n", ataque);
					int vida = Integer.parseInt(s.next());
					//System.out.printf("%d\n", vida);
					
					
					
					if(personaje.equals("Power")){
						Power.setVida(vida);
						Power.setAtaque(ataque);
						//System.out.printf("Creo Objeto Personaje\n");
					}
					else if(personaje.equals("Añya")){
						Añya.setVida(vida);
						Añya.setAtaque(ataque);
						//System.out.printf("Creo Objeto Personaje\n");
					}
					else if(personaje.equals("BestoFriendo")){
						Houdini.setVida(vida);
						Houdini.setAtaque(ataque);
						//System.out.printf("Creo Objeto Personaje\n");
					}
					else if(personaje.equals("Houdini")){
						 BestoFriendo.setVida(vida);
						 BestoFriendo.setAtaque(ataque);
						//System.out.printf("Creo Objeto Personaje\n");
					}
					else{
						System.out.printf("Se ha introducido de forma erronea algun dato");
						System.exit(0); //Termina el programa para evitar posibles bugs
					}
					
				}
				s.close();
			}catch(FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	
	public static void LeerFicheroArmas(Lanza Lanza, Martillo Martillo, Hacha Hacha, Espada Espada){
		File f = new File ("datosArmas.txt");
		Scanner s;
		
		try {
			s = new Scanner(f);
			while(s.hasNext()){
				String arma = s.next();
				//System.out.printf("%s\n", arma);
				int ataque = Integer.parseInt(s.next());
				//System.out.printf("%d\n", ataque);
				int vida = Integer.parseInt(s.next());
				//System.out.printf("%d\n", vida);
		
				if(arma.equals("Martillo")){
					Martillo.setVidaArma(vida);
					Martillo.setAtaqueArma(ataque);
					//System.out.printf("Creo Objeto Martillo\n");
				}
				else if(arma.equals("Lanza")){
					Lanza.setVidaArma(vida);
					Lanza.setAtaqueArma(ataque);
					//System.out.printf("Creo Objeto Lanza\n");
				}
				else if(arma.equals("Hacha")){
					Hacha.setVidaArma(vida);
					Hacha.setAtaqueArma(ataque);
					//System.out.printf("Creo Objeto Hacha\n");
				}else if(arma.equals("Espada")){
					 Espada.setVidaArma(vida);
					 Espada.setAtaqueArma(ataque);
					//System.out.printf("Creo Objeto Espada\n");
				}else{
					System.out.printf("Se ha introducido de forma erronea algun dato");
					System.exit(0); //Termina el programa para evitar posibles bugs
				}
				
			}
			s.close();
				
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void GestionVentanas(){
		SeleccionEnemigosInter ventana = new SeleccionEnemigosInter();
		ventana.setVisible(true);
		SeleccionPersonajeArmaInter ventana1 = new SeleccionPersonajeArmaInter();
		ventana1.setVisible(true);
		Dificultad ventana2 = new Dificultad();
		ventana2.setVisible(true);
		
		//mientras no se hayan introducido todos los datos no sale del while(así las variables se inicializan correctamente)
		while((MainJuego.NumEnemig==0) || (MainJuego.dificultad==0) || (MainJuego.personaje == null) || (MainJuego.arma == null)){
			System.out.printf(""); // para que funcione el delay del while
		}
		
		ventana1.setVisible(false);
		ventana2.setVisible(false);
		ventana.setVisible(false);
		
	}

	
	public static void GestionTurnos(Arma arma, Personaje personaje, Enemigo[] enemigo, Arma[] arrayArmas, String[] arrayResultados){
		
		System.out.println("EMPIEZA LA PARTIDA\n");
		
		
		//modificamos la vida y el atque del personaje en funcion de la arma equipada
		int danoTotal = arma.getAtaqueArma() + personaje.getAtaque();
		personaje.setAtaque(danoTotal);
		int vidaTotal = arma.getVidaArma() + personaje.getVida();
		personaje.setVida(vidaTotal);
		System.out.println("Estas son tus estadísticas:\n" + "Vida: " + personaje.getVida() + "\nAtaque: " + personaje.getAtaque() + "\n");
		
		boolean muerteEnemigos = false; //cambia a true cuando todos los enemigos están muertos
		Scanner seleccion = new Scanner(System.in);
		int select;	//selección del enemigo al que vamos a atacar
		int seleccionEnemigoRandom = 0; 	//selección del enemigo que nos va a atacar
		int selectH;	//selecciona el tipo de ataque (normal, habilidad, habilidad de clase)
		int ataqueEnemigo=0;
		String cambiarArma;
		boolean ModArma;
		int datos;
		int enemigosMuertos=0;
		
		while((personaje.getVida()>0) && (muerteEnemigos == false)){ //se acaba la gestion de turnos una vez el personaje este muerto o los enemigos estén muertos
			seleccionEnemigoRandom=(int)(Math.random()*(NumEnemig-1)); //random para elegir que enemigo ataca			
			
			/////////////////////////////TURNO DEL JUGADOR/////////////////////////////
			
			System.out.println("Le toca atacar, seleccione el enemigo que recibira el ataque: 1-" + NumEnemig);
			select = seleccion.nextInt();
			
			if((select>NumEnemig)||(select <= 0)){ //si se introduce un número fuera del rando da error
				System.out.println("Error al introducir los datos. Vuelve a introducir los datos");
			}else{
				System.out.println("Seleccione el tipo de ataque:\n1: ataque normal\n2: habilidad\n3: habilidad de clase\n4: Cambiar el arma");
				selectH = seleccion.nextInt();
				
				switch(selectH) {
					case 1:
						datos = personaje.getAtaque();
						personaje.ataqueN(enemigo[select -1]);
						System.out.println("vida enemigo es de: "+ enemigo[select-1].getVida());
						DañoDado(datos, arrayResultados, select);
						break;
					case 2:
						arrayResultados[contArray]=("Usaste tu habilidad contra el enemigo \n" + select);
						contArray++;
						personaje.HabilidadPersonaje(enemigo[select-1]);
						System.out.println("vida enemigo es de: "+ enemigo[select-1].getVida());
						cooldownHabilidad--;
						break;
					case 3:
						arrayResultados[contArray]="Usaste tu habilidad de clase\n";
						contArray++;
						personaje.HabilidadClase();
						System.out.println("Has utilizado la habilidad del personaje, tus estadisticas son: ");
						System.out.println("vida personaje: " + personaje.getVida() + " // ataque personaje: " + personaje.getAtaque());
						break;
					case 4:
						ModArma=ComprobarMod(personaje);
						if(ModArma==true){
							//le quita al personaje las estadísticas del arma anterior
							danoTotal =personaje.getAtaque() - arma.getAtaqueArma();
							personaje.setAtaque(danoTotal);
							vidaTotal =personaje.getVida() - arma.getVidaArma();
							personaje.setVida(vidaTotal);
							
							String ArmaVieja;
							ArmaVieja = MainJuego.arma.toString();							
							//se abre la ventana para volver a elegir el arma
							SeleccionPersonajeArmaInter ventana1 = new SeleccionPersonajeArmaInter();
							ventana1.setVisible(true);
							while(MainJuego.arma == ArmaVieja.toString()){
								System.out.printf(""); // para que funcione el delay del while
							}
							ventana1.setVisible(false);
							
							//añade las estadísticas del arma nueva al personaje
							if(MainJuego.arma== "Lanza"){
								danoTotal = arrayArmas[0].getAtaqueArma() + personaje.getAtaque();
								personaje.setAtaque(danoTotal);
								vidaTotal = arrayArmas[0].getVidaArma() + personaje.getVida();
								personaje.setVida(vidaTotal);
								arrayResultados[contArray]=("Cambiaste de arma, ahora atacas con la lanza\n");
								contArray++;
							}else if(MainJuego.arma== "Espada"){
								danoTotal = arrayArmas[2].getAtaqueArma() + personaje.getAtaque();
								personaje.setAtaque(danoTotal);
								vidaTotal = arrayArmas[2].getVidaArma() + personaje.getVida();
								personaje.setVida(vidaTotal);
								arrayResultados[contArray]=("Cambiaste de arma, ahora atacas con la espada\n");
								contArray++;
							}else if(MainJuego.arma== "Hacha"){
								danoTotal = arrayArmas[3].getAtaqueArma() + personaje.getAtaque();
								personaje.setAtaque(danoTotal);
								vidaTotal = arrayArmas[3].getVidaArma() + personaje.getVida();
								personaje.setVida(vidaTotal);
								arrayResultados[contArray]=("Cambiaste de arma, ahora atacas con el hacha\n");
								contArray++;
							}else if(MainJuego.arma== "Martillo"){
								danoTotal = arrayArmas[1].getAtaqueArma() + personaje.getAtaque();
								personaje.setAtaque(danoTotal);
								vidaTotal = arrayArmas[1].getVidaArma() + personaje.getVida();
								personaje.setVida(vidaTotal);
								arrayResultados[contArray]=("Cambiaste de arma, ahora atacas con el martillo\n");
								contArray++;
							}else {
								System.out.println("No introdució una opcion válida, no se cambia el arma");
							}
						}
						
						System.out.println("La vida actual de tu persobaje es de: " + personaje.getVida());
						System.out.println("El ataque actual de tu persobaje es de: " + personaje.getAtaque());
						
						break;
					default:
						System.out.println("Error al elegir la opción del menú");
				}
				
				
				/////////////////////////////TURNO DEL ENEMIGO/////////////////////////////
				
				if(enemigo[seleccionEnemigoRandom].getPuedeAtacar() == true) {	//si el enemigo puede atacar (está vivo)
					datos = enemigo[seleccionEnemigoRandom].getAtaque(arrayResultados);
					ataqueEnemigo = personaje.getVida() - datos;/*enemigo[seleccionEnemigoRandom].getAtaque();*/
					personaje.setVida(ataqueEnemigo);
					DañoRecibido(datos, arrayResultados, seleccionEnemigoRandom);
					
				}else {		//si no está vivo te vuelve a tocar
					System.out.println("El enemigo " + seleccionEnemigoRandom + " no tiene suficientes fuerzas para atacar, pierde el turno");
					arrayResultados[contArray]="Un enemigo sin  suficiente energia no pudo atacarte\n";
					contArray++;
				}
				
				for(int i =0; i<NumEnemig; i++){
					if(enemigo[i].getVida() <= 0){
						enemigo[i].setPuedeAtacar(false);	//el enemigo está muerto así que no puede atacar
						System.out.println("El enemigo " + seleccionEnemigoRandom + " ya no puede atacar más");
						arrayResultados[contArray]=("El enemigo " + i + " esta muerto\n");
						contArray++;
						enemigosMuertos++;					
					}
				}
				
				if(enemigosMuertos == NumEnemig){	//si todos los enemigos están muertos
					muerteEnemigos = true;
					arrayResultados[contArray]=("Mataste a todos los enemigos\n");
					contArray++;
				}
				
				//al final de la ronda muestra la vida de todos los enemigos y el personaje
				for(int i=0; i<NumEnemig; i++){
					System.out.println("El enemigo " + (i+1) + " tiene " + enemigo[i].getVida() + " de vida");
				}
				System.out.println("La vida de tu personaje es:" + personaje.getVida());
				
			}
			
			System.out.println("\n//SIGUIENTE TURNO//");
		}

		if(personaje.getVida() <=0){
			System.out.println("Has perdido");
			arrayResultados[contArray]=("Has perdido\n");
			contArray++;
		}else{
			System.out.println("Has Ganado");
			arrayResultados[contArray]=("Has ganado\n");
			contArray++;
		}

	}

	
	public static void DañoDado(int datos, String[] arrayResultados, int numEnemigo){
		arrayResultados[contArray]=("Hiciste " + datos + " de daño al enemigo " + (numEnemigo) + "\n");
		contArray++;
	}
	
	public static void DañoRecibido(int datos, String[] arrayResultados, int numEnemigo){
		arrayResultados[contArray]=("Recibiste " + datos + " de daño del enemigo " + (numEnemigo+1) + "\n");
		contArray++;
		System.out.println("Recibiste " + datos + "ptos de daño del enemigo\n");
		
	}
	
	public static boolean ComprobarMod(Personaje personaje) {
		boolean comprobar=false;
		if(personaje.getVida() < 125)
		{
			comprobar=true;
		}else {
			System.out.println("No se puede cambiar de arma aún");
		}
		return comprobar;
	}
}

