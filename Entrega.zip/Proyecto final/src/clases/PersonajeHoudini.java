package clases;

public class PersonajeHoudini extends Personaje{
	//contructor
	public PersonajeHoudini(int vida, int ataque) {
		super(vida, ataque);
		
	}
	
	//ataque normal
	public void ataqueN(Enemigo enemigo1) {
		int vidaE = enemigo1.getVida() -this.getAtaque();
		enemigo1.setVida(vidaE);
		
	}
	
	//habilidad
	public void HabilidadPersonaje(Enemigo enemigo1) {
		if(MainJuego.cooldownHabilidad!=0) {
			System.out.printf("Te quedan %d turnos hasta que puedas usar la habilidad\n", MainJuego.cooldownHabilidad);
		}else {
			int vidaE = enemigo1.getVida() -60;
			enemigo1.setVida(vidaE);
			MainJuego.cooldownHabilidad=4;
		}
	}

		//habilidad de DPS
	public void HabilidadClase() {
		MainJuego.cooldownHabilidad=0;
		System.out.printf("La habilidad elimino el cooldown\n");
			
	}	
	
}
