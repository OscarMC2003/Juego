package clases;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class SeleccionPersonajeArmaInter extends JFrame implements ActionListener{
	
	JButton Añya, Power, Besto, Houdini, Espada, Martillo, Lanza, Hacha;
	JLabel prompt1, prompt2;
	Container contentPane=getContentPane();
	
	boolean elegirP=false;
	boolean elegirA=false;
	
	public SeleccionPersonajeArmaInter()
	{
		
		prompt1 = new JLabel();
		prompt1.setText("Selecciona tu personaje: ");
		prompt1.setSize(150, 25);
		
		Añya = new JButton();
		Añya.setText("Añya");
		Añya.addActionListener(this);
		Power = new JButton();
		Power.setText("Power");
		Power.addActionListener(this);
		Besto = new JButton();
		Besto.setText("Besto");
		Besto.addActionListener(this);
		Houdini = new JButton();
		Houdini.setText("Houdini");
		Houdini.addActionListener(this);
		
		JPanel Matriz1 = new JPanel();
		
		Matriz1.setLayout(new GridLayout(1,4));
		Matriz1.add(Añya);
		Matriz1.add(Besto);
		Matriz1.add(Power);
		Matriz1.add(Houdini);
		
		
		
		prompt2 = new JLabel();
		prompt2.setText("Selecciona tu arma: ");		
		prompt2.setSize(150, 25);
		
		Lanza = new JButton();
		Lanza.setText("Lanza");
		Lanza.addActionListener(this);
		Espada = new JButton();
		Espada.setText("Espada");
		Espada.addActionListener(this);
		Hacha = new JButton();
		Hacha.setText("Hacha");
		Hacha.addActionListener(this);
		Martillo = new JButton();
		Martillo.setText("Martillo");
		Martillo.addActionListener(this);
		
		JPanel Matriz2  = new JPanel();
		
		Matriz2.setLayout(new GridLayout(1,4));
		Matriz2.add(Lanza);
		Matriz2.add(Espada);
		Matriz2.add(Hacha);
		Matriz2.add(Martillo);
		
		setSize(500, 150);
		setTitle("Juego Battle Royale");
		setLocation(500,330);
		setLayout(new FlowLayout());
		add(prompt1);
		add(Matriz1);
		add(prompt2);
		add(Matriz2);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	
	public void actionPerformed(ActionEvent e) {
		
		//elegir un personaje solo una vez
		if(elegirP==false) {
			//System.out.println(contP);
			if(e.getSource()==Añya) {
				//System.out.printf("funciono a\n");
				MainJuego.personaje=Añya.getText();
				elegirP=true;
				contentPane.setBackground(Color.PINK);
			}else if(e.getSource()==Power) {
				//System.out.printf("funciono b\n");
				MainJuego.personaje=Power.getText();
				elegirP=true;
				contentPane.setBackground(Color.yellow);
			}else if(e.getSource()==Besto) {
				//System.out.printf("funciono c\n");
				MainJuego.personaje=Besto.getText();
				elegirP=true;
				contentPane.setBackground(Color.blue);
			}else if(e.getSource()==Houdini) {
				//System.out.printf("funciono d\n");
				MainJuego.personaje=Houdini.getText();
				elegirP=true;
				contentPane.setBackground(Color.green);
			}
		}else {
			/*Si no el if no funciona*/
		}
		
		//elegir el arma solo una vez
		if(elegirA==false) {
			//System.out.println(contP);
			if(e.getSource()==Lanza) {
				//System.out.printf("funciono a\n");
				MainJuego.arma=Lanza.getText();
				elegirA=true;
			}else if(e.getSource()==Espada) {
				//System.out.printf("funciono b\n");
				MainJuego.arma=Espada.getText();
				elegirA=true;
			}else if(e.getSource()==Hacha) {
				//System.out.printf("funciono c\n");
				MainJuego.arma=Hacha.getText();
				elegirA=true;
			}else if(e.getSource()==Martillo) {
				//System.out.printf("funciono d\n");
				MainJuego.arma=Martillo.getText();
				elegirA=true;
			}
		}else{
			/*Si no el if no funciona*/
		}
	}

}
