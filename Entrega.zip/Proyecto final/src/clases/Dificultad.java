package clases;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Dificultad extends JFrame implements ActionListener{
	
	JButton Baja, Media, Alta;
	JLabel prompt;
	Container contentPane=getContentPane();
	
	boolean elegirD=false;
	
	public Dificultad() {
		
		prompt = new JLabel();
		prompt.setText("Selecciona la dificultad: ");
		prompt.setSize(150, 25);
		
		Baja = new JButton();
		Baja.setText("Baja");
		Baja.addActionListener(this);
		Media = new JButton();
		Media.setText("Media");
		Media.addActionListener(this);
		Alta = new JButton();
		Alta.setText("Alta");
		Alta.addActionListener(this);
		
		JPanel Matriz1 = new JPanel();
		
		Matriz1.setLayout(new GridLayout(1,4));
		Matriz1.add(Baja);
		Matriz1.add(Media);
		Matriz1.add(Alta);
		
		setSize(500, 150);
		setTitle("Juego Battle Royale");
		setLocation(500,160);
		setLayout(new FlowLayout());
		add(prompt);
		add(Matriz1);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//contentPane.setBackground(Color.gray);
		
	}
	
public void actionPerformed(ActionEvent e) {
		
		//elegir un personaje solo una vez
		if(elegirD==false) {
			//System.out.println(contP);
			if(e.getSource()==Baja) {
				//System.out.printf("funciono a\n");
				MainJuego.dificultad=1;
				elegirD=true;
				contentPane.setBackground(Color.green);
			}else if(e.getSource()==Media) {
				//System.out.printf("funciono b\n");
				MainJuego.dificultad=2;
				contentPane.setBackground(Color.orange);
			}else if(e.getSource()==Alta) {
				//System.out.printf("funciono c\n");
				MainJuego.dificultad=3;
				elegirD=true;
				contentPane.setBackground(Color.red);
			}
		}else {
			/*Si no el if no funciona*/
		}
}
	
}
