package clases;

public abstract class Personaje {
	//atributos
	private int vida=0;
	private int ataque=0;
	
	//constructor
	public Personaje(int vida, int ataque) {
		this.vida = vida;
		this.ataque = ataque;
	}
	
	//getters y setters
	public int getVida() {
		return vida;
	}
	
	public  void setVida(int vida) {
		this.vida = vida;
	}
	public int getAtaque() {
		return ataque;
	}
	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}

	public abstract void HabilidadPersonaje(Enemigo enemigo1);

	public abstract void ataqueN(Enemigo enemigo);

	public abstract void HabilidadClase();
	

	
}
