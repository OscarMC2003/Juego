package clases;

public class Enemigo {
	//atributos
	private int vida;
	private int ataque;
	private boolean puedeAtacar;
	
	//constructor
	public Enemigo() {
		
		switch(MainJuego.dificultad) {
			case 1:
				this.vida = 350;
				this.ataque = 40;
				this.puedeAtacar = true;
				break;
			case 2:
				this.vida = 400;
				this.ataque = 60;
				this.puedeAtacar = true;
				break;
			case 3:
				this.vida = 450;
				this.ataque = 75;
				this.puedeAtacar = true;
				break;
			default:
				System.out.println("Error al elegir la dificultad");
		}
	}
	
	//getters y setters
	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public int getAtaque(String[] arrayResultados) {
		
		int numero= (int)(Math.random()*10 +1);
		int numero1= (int)(Math.random()*10 +1);
		int numero2= (int)(Math.random()*10 +1);
		int numeroAtaquePlus= (int)(Math.random()*16 +5); //genera numero entre 25 y 75
		
		if(numero == numero1)
		{
			System.out.println("El enemigo tuvo un golpe de suerte y aumenta su ataque en " + numeroAtaquePlus+ "pts\n");
			this.ataque= this.ataque + numeroAtaquePlus;
			arrayResultados[MainJuego.contArray]=("El enemeigo atacante tuvo un golpe de suerte y su ataque aumenta en" + numeroAtaquePlus+ "pts\n");
			MainJuego.contArray++;
		}else if(numero == numero2)
		{
			System.out.println("El enemigo recibió daño amigo, su ataque disminuye en " + numeroAtaquePlus+ "pts\n");
			this.ataque= this.ataque - numeroAtaquePlus;
			arrayResultados[MainJuego.contArray]=("El enemeigo recibió ataque amigo, por lo que su ataque disminuye en " + numeroAtaquePlus+ "pts\n");
			MainJuego.contArray++;
		}
		return ataque;
	}

	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}

	public boolean getPuedeAtacar() {
		return puedeAtacar;
	}

	public void setPuedeAtacar(boolean puedeAtacar) {
		this.puedeAtacar = puedeAtacar;
	}
	
	
	
}
