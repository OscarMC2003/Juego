package clases;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class SeleccionEnemigosInter  extends JFrame implements ActionListener{

		JTextField campo;
		JLabel prompt;
		
		public SeleccionEnemigosInter()
		{
			campo = new JTextField();
			campo.setColumns(10);
			campo.addActionListener(this);
			prompt = new JLabel();
			prompt.setText("Introduce el numero de enemigos(Max 5): ");
			prompt.setSize(150, 25);
			setSize(500, 150);
			setTitle("Juego Battle Royale");
			setLocation(500,500);
			setLayout(new FlowLayout());
			add(prompt);
			add(campo);
			setDefaultCloseOperation(EXIT_ON_CLOSE);
		}

		
		public void actionPerformed(ActionEvent e) {
			
			try {
				int num=Integer.parseInt(campo.getText());
				if(num<=0||num>5) {
					System.out.println("Valor introducido no válido. Seleccione un valor entre 1 y 5");
				}else {
					MainJuego.NumEnemig=num;
				}
				//	System.out.println(campo.getText());
			}catch(NumberFormatException e1) {
				System.out.printf("Error: debes introducir un número\n");
				System.out.println(MainJuego.NumEnemig);
			}
			
		}
		

}
