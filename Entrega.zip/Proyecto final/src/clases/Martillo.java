package clases;

public class Martillo extends Arma{
	
	int ataqueArma=0;
	int vidaArma=0;

	public Martillo(int ataqueArma, int vidaArma) {
		super(ataqueArma, vidaArma);
	}

	public int getAtaqueArma() {
		return ataqueArma;
	}

	public void setAtaqueArma(int ataqueArma) {
		this.ataqueArma = ataqueArma;
	}

	public int getVidaArma() {
		return vidaArma;
	}

	public void setVidaArma(int vidaArma) {
		this.vidaArma = vidaArma;
	}
}
