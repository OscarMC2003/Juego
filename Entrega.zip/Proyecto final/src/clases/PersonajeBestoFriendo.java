package clases;

public class PersonajeBestoFriendo extends Personaje {
	//contructor
	public PersonajeBestoFriendo(int vida, int ataque) {
		super(vida, ataque);
		
	}
	
	//ataque normal
	public void ataqueN(Enemigo enemigo1) {
		int vidaE = enemigo1.getVida() -this.getAtaque();
		enemigo1.setVida(vidaE);
		
	}
	
	//habilidad
	public void HabilidadPersonaje(Enemigo enemigo1) {
		int vidaE = enemigo1.getVida() -95;
		enemigo1.setVida(vidaE);
	}
	
	//habilidad de DPS
	public void HabilidadClase() {
		int vidaP=this.getVida() -20;
		this.setVida(vidaP);
		int ataqueP=this.getAtaque() +20;
		this.setVida(ataqueP);
	}
}
